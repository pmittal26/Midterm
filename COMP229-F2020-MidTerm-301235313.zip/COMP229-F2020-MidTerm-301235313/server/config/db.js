//db.js
//Mittal Patel
//301235313
//Mid-term exam(my faviroute book-list)



module.exports = {

  //local MongoDB deployment ->
  //"URI":"mongodb+srv://mittal123:MuJ7FqDiLQsIKJ8c@cluster0.tlyguvq.mongodb.net/?retryWrites=true&w=majority"
  "URI":"mongodb+srv://mittal123:MuJ7FqDiLQsIKJ8c@cluster0.tlyguvq.mongodb.net/?retryWrites=true&w=majority"
  //"URI": "mongodb://127.0.0.1:27017/books"
};
